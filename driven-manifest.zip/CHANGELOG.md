# Changelog

## 1.0.3 - January 10, 2017

### Icon Paths Issue
- Fix paths issues with icons not being rendered correctly.

## 1.0.0 - November 28, 2016

### Initial Commit
- Upload of all code and files for version 1.0

